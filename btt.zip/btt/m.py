import os,time
from threading import Thread
from flask import Flask

# استيراد التطبيق من ملف البوت الأصلي (بدون تشغيله)
# تأكد أن اسم الملف هو "bot_core.py" أو عدله حسب اسم ملفك
from btt import bot

app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is alive!"

if __name__ == "__main__":
    # نشغل polling في خيط منفصل
    def run_bot_polling():
        # نزيل webhook احتياطاً
        try:
            bot.remove_webhook()
        except:
            pass
        # تشغيل البوت بطريقة لا نهائية
        while True:
            try:
                bot.polling(none_stop=True, interval=1, timeout=30)
            except Exception as e:
                print(f"Polling error: {e}")
                time.sleep(10)

    bot_thread = Thread(target=run_bot_polling, daemon=True)
    bot_thread.start()

    # نشغل Flask في الخيط الرئيسي (اللي Pella ينتظره)
    port = int(os.environ.get("PORT", 3000))
    app.run(host="0.0.0.0", port=port)